<!DOCTYPE html>
<html>
<head>
        <title>Ordering System</title>

	<link rel="stylesheet" href="style.css" type="text/css" />
<style>

</style>
	
</head>
<body>

	<div id="page">
		
	<div id="banner">
			<h1><b>Auto Parts Ordering <br>System</b></h1>

		</div>
		
		<div id="nav">
			<ul>
				<li><a href="index.php">About Us</a></li>
                                <li><a href="shop.php">Shop</a></li>
                                <li><a href="return.php">Return Shipment</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>	
		</div>
		<div id="content">
			<h2><b>Contact Information :</b></h2><br><br>
<ul>
<li> Nayya Myneni - 8155931692</li><br>
<br>
<li> Nikhil Bejugam - 8155936877</li><br>
<br>
<li> Lohith Boinapally - 6086097578</li><br>
<br>
</ul>

                         
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		</div>
<div id="footer">
			<p><center>
				Powered by <a href="/" target="_blank">Team 9</a></center>
			</p>
		</div>
			</div>
 
</div>
</body>
</html>